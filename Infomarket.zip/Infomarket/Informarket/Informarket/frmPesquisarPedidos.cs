﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmPesquisarPedidos : Form
    {
        SqlConnection con = Conexao.getConnection();
        SqlDataAdapter adapt;

        private void ExibirDados()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT codpedido, nomecliente, c.rg, c.cpf, c.cidade, c.telefone, c.celular, nomeproduto, pr.marca, pr.preco, p.quantidade, datapedido, fu.nomecompleto, f.nome FROM Pedidos p INNER JOIN Clientes c ON (p.codcli = c.codcli) INNER JOIN Produtos pr ON (pr.codproduto = p.codproduto) INNER JOIN Fabricantes f ON (f.codfabricante = p.codfabricante) INNER JOIN Funcionarios fu ON (fu.codfuncionario = p.codfuncionario) ORDER BY nomecliente", con);
                adapt.Fill(dt);
                dtPedidos.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        public frmPesquisarPedidos()
        {
            InitializeComponent();
            ExibirDados();
            
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void frmConsultarProdutos_Load(object sender, EventArgs e)
        {
            dtPedidos.Columns[0].HeaderText = "Código Pedido";
            dtPedidos.Columns[1].HeaderText = "Nome Cliente";
            dtPedidos.Columns[2].HeaderText = "RG";
            dtPedidos.Columns[3].HeaderText = "CPF";
            dtPedidos.Columns[4].HeaderText = "Cidade";
            dtPedidos.Columns[5].HeaderText = "Telefone";
            dtPedidos.Columns[6].HeaderText = "Celular";
            dtPedidos.Columns[7].HeaderText = "Descrição Produto";
            dtPedidos.Columns[8].HeaderText = "Marca";
            dtPedidos.Columns[9].HeaderText = "Preço";
            dtPedidos.Columns[10].HeaderText = "Quantidade";
            dtPedidos.Columns[11].HeaderText = "Data Pedido";
            dtPedidos.Columns[12].HeaderText = "Nome Funcionário";
            dtPedidos.Columns[13].HeaderText = "Nome Fabricante";
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if(txtNome.Text != "" && mskCPF.Text != "" && mskRG.Text != "")
            {
                try
                {
                    con.Open();
                    DataTable dt = new DataTable();
                    adapt = new SqlDataAdapter("SELECT codpedido, nomecliente, c.rg, c.cpf, c.cidade, c.telefone, c.celular, nomeproduto, pr.marca, pr.preco, p.quantidade, datapedido, fu.nomecompleto, f.nome FROM Pedidos p INNER JOIN Clientes c ON (p.codcli = c.codcli) INNER JOIN Produtos pr ON (pr.codproduto = p.codproduto) INNER JOIN Fabricantes f ON (f.codfabricante = p.codfabricante) INNER JOIN Funcionarios fu ON (fu.codfuncionario = p.codfuncionario) WHERE (c.nome = '" + txtNome.Text + "') AND (c.rg = '" + mskRG.Text + "') AND (c.cpf = '" + mskCPF.Text + "') ORDER BY c.nome", con);
                    adapt.Fill(dt);
                    dtPedidos.DataSource = dt;
                    MessageBox.Show("Sua pesquisa foi concluída!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else if(txtNome.Text == "" || mskCPF.Text == "" || mskRG.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
            }
            else
            {
                MessageBox.Show("Nenhum registro encontrado!");
            }
        }

        private void fillByTudoToolStripButton_Click(object sender, EventArgs e)
        {
            

        }

        private void dtPedidos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            mskRG.Text = "";
            mskCPF.Text = "";
            ExibirDados();
        }
    }
}
