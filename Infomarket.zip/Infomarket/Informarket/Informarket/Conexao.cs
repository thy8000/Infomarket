﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Informarket
{
    public class Conexao
    {
        public static SqlConnection getConnection()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Thunay\Documents\Uninove\Projeto\C#\Infomarket\Informarket\Informarket\Infomarket.mdf;Integrated Security=True;Connect Timeout=30");
            return con;
        }

    }
}
