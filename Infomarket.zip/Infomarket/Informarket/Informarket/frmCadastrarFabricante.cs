﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmCadastrarFabricante : Form
    {
        SqlConnection con = Conexao.getConnection();
        SqlCommand cmd;
        SqlDataAdapter adapt;
        int ID = 0;

        public frmCadastrarFabricante()
        {
            InitializeComponent();
            ExibirDados();
        }

        private void ExibirDados()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT * FROM Fabricantes", con);
                adapt.Fill(dt);
                dtFabricantes.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void LimparDados()
        {
            txtNome.Text = "";
            txtCNPJ.Text = "";
            txtCodigo.Text = "";
            ID = 0;
        }



        private void frmCadastrarCategorias_Load(object sender, EventArgs e)
        {
            dtFabricantes.Columns[0].HeaderText = "Código";
            dtFabricantes.Columns[1].HeaderText = "Nome";
            dtFabricantes.Columns[2].HeaderText = "CNPJ";
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text != "" && txtCNPJ.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("INSERT INTO Fabricantes(nome, cnpj) VALUES(@nome, @cnpj)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@nome", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cnpj", Convert.ToInt64(txtCNPJ.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro incluído com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("UPDATE Fabricantes SET nome=@nome, cnpj=@cnpj WHERE codfabricante=@codfabricante", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@codfabricante", Convert.ToInt64(ID));
                    cmd.Parameters.AddWithValue("@nome", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cnpj", Convert.ToInt64(txtCNPJ.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro atualizado com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void dtCategorias_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                ID = Convert.ToInt32(dtFabricantes.Rows[e.RowIndex].Cells[0].Value.ToString());
                txtCodigo.Text = dtFabricantes.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtNome.Text = dtFabricantes.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtCNPJ.Text = dtFabricantes.Rows[e.RowIndex].Cells[2].Value.ToString();
            }
            catch { }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtCNPJ.Text = "";
            txtCodigo.Text = "";
            txtNome.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                if (MessageBox.Show("Deseja Deletar este registro ?", "Infomarket", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        cmd = new SqlCommand("DELETE Fabricantes WHERE codfabricante=@codfabricante", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@codfabricante", ID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("registro deletado com sucesso...!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro : " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                        ExibirDados();
                        LimparDados();
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecione um registro para deletar");
            }
        }
    }
}
