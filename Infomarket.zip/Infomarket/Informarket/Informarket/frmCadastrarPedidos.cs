﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmCadastrarPedidos : Form
    {

        SqlConnection con = Conexao.getConnection();
        SqlCommand cmd;
        SqlDataAdapter adapt;
        int ID = 0;

        public frmCadastrarPedidos()
        {
            InitializeComponent();
            ExibirDados();
            ExibirDadosClientes();
            ExibirDadosProdutos();
        }

        private void ExibirDados()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT codpedido, nomecliente, rg, cpf, cidade, telefone, celular, nomeproduto, marca, preco, quantidade, datapedido, codcli, codfuncionario, codproduto, codfabricante FROM Pedidos ORDER BY codcli", con);
                adapt.Fill(dt);
                dtPedidos.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void ExibirDadosClientes()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT codcli, nome, rg, cpf, cidade, telefone, celular, codfuncionario FROM Clientes", con);
                adapt.Fill(dt);
                dtClientes.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void ExibirDadosProdutos()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT codproduto, nome, marca, preco, quantidade, codfabricante FROM Produtos", con);
                adapt.Fill(dt);
                dtProdutos.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void LimparDados()
        {
            txtNomeProduto.Text = "";
            txtMarca.Text = "";
            txtPreco.Text = "";
            txtQuantidade.Text = "";
            txtFabricante.Text = "";
            txtNomeCliente.Text = "";
            mskRG.Text = "";
            mskCPF.Text = "";
            txtCidade.Text = "";
            mskTelefone.Text = "";
            mskCelular.Text = "";
            txtCodCliente.Text = "";
            txtCodFuncionario.Text = "";
            txtCodProduto.Text = "";
            mskDataPedido.Text = "";
            ID = 0;
        }

        private void dtClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCodProduto.Text = dtProdutos.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNomeProduto.Text = dtProdutos.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtMarca.Text = dtProdutos.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtPreco.Text = dtProdutos.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtFabricante.Text = dtProdutos.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void frmCadastrarPedidos_Load(object sender, EventArgs e)
        {
            dtClientes.Columns[0].HeaderText = "Código Cliente";
            dtClientes.Columns[1].HeaderText = "Nome";
            dtClientes.Columns[2].HeaderText = "RG";
            dtClientes.Columns[3].HeaderText = "CPF";
            dtClientes.Columns[4].HeaderText = "Cidade";
            dtClientes.Columns[5].HeaderText = "Telefone";
            dtClientes.Columns[6].HeaderText = "Celular";
            dtClientes.Columns[7].HeaderText = "Código Funcionário";

            dtProdutos.Columns[0].HeaderText = "Código Produto";
            dtProdutos.Columns[1].HeaderText = "Descrição Produto";
            dtProdutos.Columns[2].HeaderText = "Marca";
            dtProdutos.Columns[3].HeaderText = "Preço";
            dtProdutos.Columns[4].HeaderText = "Estoque";
            dtProdutos.Columns[5].HeaderText = "Código Fabricante";

            dtPedidos.Columns[0].HeaderText = "Código Pedido";
            dtPedidos.Columns[1].HeaderText = "Nome Cliente";
            dtPedidos.Columns[2].HeaderText = "RG";
            dtPedidos.Columns[3].HeaderText = "CPF";
            dtPedidos.Columns[4].HeaderText = "Cidade";
            dtPedidos.Columns[5].HeaderText = "Telefone";
            dtPedidos.Columns[6].HeaderText = "Celular";
            dtPedidos.Columns[7].HeaderText = "Nome Produto";
            dtPedidos.Columns[8].HeaderText = "Marca";
            dtPedidos.Columns[9].HeaderText = "Preço";
            dtPedidos.Columns[10].HeaderText = "Quantidade";
            dtPedidos.Columns[11].HeaderText = "Data Pedido";
            dtPedidos.Columns[12].HeaderText = "Código Cliente";
            dtPedidos.Columns[13].HeaderText = "Código Funcionário";
            dtPedidos.Columns[14].HeaderText = "Código Produto";
            dtPedidos.Columns[15].HeaderText = "Código Fabricante";
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtCidade.Text != "" && txtFabricante.Text != "" && txtMarca.Text != "" && txtNomeCliente.Text != "" && txtNomeProduto.Text != "" && txtPreco.Text != "" && txtQuantidade.Text != "" && mskCelular.Text != "" && mskCPF.Text != "" && mskRG.Text != "" && mskTelefone.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("INSERT INTO Pedidos(nomecliente, rg, cpf, cidade, telefone, celular, nomeproduto, marca, preco, quantidade,datapedido, codcli, codfuncionario, codproduto, codfabricante) VALUES(@nomecliente, @rg, @cpf, @cidade, @telefone, @celular, @nomeproduto, @marca, @preco, @quantidade, @datapedido, @codcli, @codfuncionario, @codproduto, @codfabricante)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@nomecliente", Convert.ToString(txtNomeCliente.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cidade", Convert.ToString(txtCidade.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@celular", Convert.ToInt64(mskCelular.Text.ToString()));
                    cmd.Parameters.AddWithValue("@nomeproduto", Convert.ToString(txtNomeProduto.Text.ToString()));
                    cmd.Parameters.AddWithValue("@marca", Convert.ToString(txtMarca.Text.ToString()));
                    cmd.Parameters.AddWithValue("@preco", Convert.ToDecimal(txtPreco.Text.ToString()));
                    cmd.Parameters.AddWithValue("@quantidade", Convert.ToInt64(txtQuantidade.Text.ToString()));
                    cmd.Parameters.AddWithValue("@datapedido", Convert.ToDateTime(mskDataPedido.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codcli", Convert.ToInt32(txtCodCliente.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codfuncionario", Convert.ToInt32(txtCodFuncionario.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codproduto", Convert.ToInt32(txtCodProduto.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codfabricante", Convert.ToInt32(txtFabricante.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro incluído com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (txtCidade.Text != "" && txtFabricante.Text != "" && txtMarca.Text != "" && txtNomeCliente.Text != "" && txtNomeProduto.Text != "" && txtPreco.Text != "" && txtQuantidade.Text != "" && mskCelular.Text != "" && mskCPF.Text != "" && mskRG.Text != "" && mskTelefone.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("UPDATE Pedidos SET nomecliente=@nomecliente, rg=@rg, cpf=@cpf, cidade=@cidade, telefone=@telefone, celular=@celular, nomeproduto=@nomeproduto, marca=@marca, preco=@preco, quantidade=@quantidade, datapedido=@datapedido, codcli=@codcli, codfuncionario=@codfuncionario, codproduto=@codproduto, codfabricante=@codfabricante WHERE codpedido=@codpedido", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@codpedido", Convert.ToInt32(ID));
                    cmd.Parameters.AddWithValue("@nomecliente", Convert.ToString(txtNomeCliente.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cidade", Convert.ToString(txtCidade.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@celular", Convert.ToInt64(mskCelular.Text.ToString()));
                    cmd.Parameters.AddWithValue("@nomeproduto", Convert.ToString(txtNomeProduto.Text.ToString()));
                    cmd.Parameters.AddWithValue("@marca", Convert.ToString(txtMarca.Text.ToString()));
                    cmd.Parameters.AddWithValue("@preco", Convert.ToDecimal(txtPreco.Text.ToString()));
                    cmd.Parameters.AddWithValue("@quantidade", Convert.ToInt64(txtQuantidade.Text.ToString()));
                    cmd.Parameters.AddWithValue("@datapedido", Convert.ToDateTime(mskDataPedido.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codcli", Convert.ToInt32(txtCodCliente.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codfuncionario", Convert.ToInt32(txtCodFuncionario.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codproduto", Convert.ToInt32(txtCodProduto.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codfabricante", Convert.ToInt32(txtFabricante.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro atualizado com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                if (MessageBox.Show("Deseja Deletar este registro ?", "Infomarket", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        cmd = new SqlCommand("DELETE Pedidos WHERE codpedido=@codpedido", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@codpedido", Convert.ToInt32(ID));
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("registro deletado com sucesso...!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro : " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                        ExibirDados();
                        LimparDados();
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtNomeProduto.Text = "";
            txtMarca.Text = "";
            txtPreco.Text = "";
            txtQuantidade.Text = "";
            txtFabricante.Text = "";
            txtNomeCliente.Text = "";
            mskRG.Text = "";
            mskCPF.Text = "";
            txtCidade.Text = "";
            mskTelefone.Text = "";
            mskCelular.Text = "";
            txtCodCliente.Text = "";
            txtCodFuncionario.Text = "";
            txtCodProduto.Text = "";
            mskDataPedido.Text = "";
            txtNomeProduto.Focus();
        }

        private void dtPedidos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = Convert.ToInt32(dtPedidos.Rows[e.RowIndex].Cells[0].Value.ToString());
            txtNomeCliente.Text = dtPedidos.Rows[e.RowIndex].Cells[1].Value.ToString();
            mskRG.Text = dtPedidos.Rows[e.RowIndex].Cells[2].Value.ToString();
            mskCPF.Text = dtPedidos.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtCidade.Text = dtPedidos.Rows[e.RowIndex].Cells[4].Value.ToString();
            mskTelefone.Text = dtPedidos.Rows[e.RowIndex].Cells[5].Value.ToString();
            mskCelular.Text = dtPedidos.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtNomeProduto.Text = dtPedidos.Rows[e.RowIndex].Cells[7].Value.ToString();
            txtMarca.Text = dtPedidos.Rows[e.RowIndex].Cells[8].Value.ToString();
            txtPreco.Text = dtPedidos.Rows[e.RowIndex].Cells[9].Value.ToString();
            txtQuantidade.Text = dtPedidos.Rows[e.RowIndex].Cells[10].Value.ToString();
            mskDataPedido.Text = dtPedidos.Rows[e.RowIndex].Cells[11].Value.ToString();
            txtCodCliente.Text = dtPedidos.Rows[e.RowIndex].Cells[12].Value.ToString();
            txtCodFuncionario.Text = dtPedidos.Rows[e.RowIndex].Cells[13].Value.ToString();
            txtCodProduto.Text = dtPedidos.Rows[e.RowIndex].Cells[14].Value.ToString();
            txtFabricante.Text = dtPedidos.Rows[e.RowIndex].Cells[15].Value.ToString();
        }

        private void dtClientes_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            txtCodCliente.Text = dtClientes.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNomeCliente.Text = dtClientes.Rows[e.RowIndex].Cells[1].Value.ToString();
            mskRG.Text = dtClientes.Rows[e.RowIndex].Cells[2].Value.ToString();
            mskCPF.Text = dtClientes.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtCidade.Text = dtClientes.Rows[e.RowIndex].Cells[4].Value.ToString();
            mskTelefone.Text = dtClientes.Rows[e.RowIndex].Cells[5].Value.ToString();
            mskCelular.Text = dtClientes.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtCodFuncionario.Text = dtClientes.Rows[e.RowIndex].Cells[7].Value.ToString();
        }
    }
}
