﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmCadastrarProdutos : Form
    {
        SqlConnection con = Conexao.getConnection();
        SqlCommand cmd;
        SqlDataAdapter adapt;
        SqlDataReader reader;
        int ID = 0;

        public frmCadastrarProdutos()
        {
            InitializeComponent();
            ExibirDados();
        }

        public class Fabricantes
        {
            public int codfabricante { get; set; }
        }

        public IEnumerable<Fabricantes> GetFabricantes()
        {
            cmd = new SqlCommand("SELECT codfabricante FROM Fabricantes ORDER BY codfabricante", con);
            {
                con.Open();
                reader = cmd.ExecuteReader();
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            yield return new Fabricantes()
                            {
                                codfabricante = reader.GetInt32(0),
                            };
                        }
                    }
                }
                con.Close();
            }
        }

        private void ExibirDados()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT codproduto, p.nome, p.marca, p.preco, p.quantidade, f.nome FROM Produtos p INNER JOIN Fabricantes f ON (p.codfabricante = f.codfabricante)", con);
                adapt.Fill(dt);
                dtProdutos.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void LimparDados()
        {
            txtNome.Text = "";
            txtMarca.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            ID = 0;
            txtCodProduto.Text = "";
        }

        private void frmCadastrarProdutos_Load(object sender, EventArgs e)
        {
            dtProdutos.Columns[0].HeaderText = "Código Produto";
            dtProdutos.Columns[1].HeaderText = "Descrição";
            dtProdutos.Columns[2].HeaderText = "Marca";
            dtProdutos.Columns[3].HeaderText = "Preço";
            dtProdutos.Columns[4].HeaderText = "Estoque";
            dtProdutos.Columns[5].HeaderText = "Fabricante";

            cbFabricante.DropDownStyle = ComboBoxStyle.DropDownList;
            cbFabricante.DataSource = GetFabricantes().ToArray();
            cbFabricante.ValueMember = "codfabricante";
            cbFabricante.DisplayMember = "codfabricante";
            cbFabricante.Update();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
        }

        private void fillByToolStripButton_Click_1(object sender, EventArgs e)
        {
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text != "" && txtMarca.Text != "" && txtPreco.Text != "" && txtQuantidade.Text != "" && cbFabricante.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("INSERT INTO Produtos(nome, marca, preco, quantidade, codfabricante) VALUES(@nome, @marca, @preco, @quantidade, @codfabricante)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@nome", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@marca", Convert.ToString(txtMarca.Text.ToString()));
                    cmd.Parameters.AddWithValue("@preco", Convert.ToDecimal(txtPreco.Text.ToUpper()));
                    cmd.Parameters.AddWithValue("@quantidade", Convert.ToInt64(txtQuantidade.Text.ToUpper()));
                    cmd.Parameters.AddWithValue("@codfabricante", Convert.ToInt32(cbFabricante.Text.ToUpper()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro incluído com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text != "" && txtMarca.Text != "" && txtPreco.Text != "" && txtQuantidade.Text != "" && cbFabricante.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("UPDATE Produtos SET nome=@nome, marca=@marca, preco=@preco, quantidade=@quantidade, codfabricante=@codfabricante WHERE codproduto=@codproduto", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@codproduto", Convert.ToInt32(ID));
                    cmd.Parameters.AddWithValue("@nome", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@marca", Convert.ToString(txtMarca.Text.ToString()));
                    cmd.Parameters.AddWithValue("@preco", Convert.ToDecimal(txtPreco.Text.ToUpper()));
                    cmd.Parameters.AddWithValue("@quantidade", Convert.ToInt64(txtQuantidade.Text.ToUpper()));
                    cmd.Parameters.AddWithValue("@codfabricante", Convert.ToInt32(cbFabricante.Text.ToUpper()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro atualizado com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void dtProdutos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = Convert.ToInt32(dtProdutos.Rows[e.RowIndex].Cells[0].Value.ToString());
            txtCodProduto.Text = dtProdutos.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = dtProdutos.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtMarca.Text = dtProdutos.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtPreco.Text = dtProdutos.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtQuantidade.Text = dtProdutos.Rows[e.RowIndex].Cells[4].Value.ToString();
            cbFabricante.Text = dtProdutos.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtMarca.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            txtCodProduto.Text = "";
            txtNome.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                if (MessageBox.Show("Deseja Deletar este registro ?", "Infomarket", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        cmd = new SqlCommand("DELETE Produtos WHERE codproduto=@codproduto", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@codproduto", ID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("registro deletado com sucesso...!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro : " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                        ExibirDados();
                        LimparDados();
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecione um registro para deletar");
            }
        }

        private void cbFabricante_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}

