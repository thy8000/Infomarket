﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmConsultarFuncionarios : Form
    {
        SqlConnection con = Conexao.getConnection();
        SqlCommand cmd;
        SqlDataAdapter adapt;
        SqlDataReader reader;
        int ID = 0;

        public frmConsultarFuncionarios()
        {
            InitializeComponent();
            ExibirDados();
        }

        private void ExibirDados()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT * FROM Funcionarios ORDER BY nomecompleto", con);
                adapt.Fill(dt);
                dtFuncionarios.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void LimparDados()
        {
            txtNome.Text = "";
            txtCodigo.Text = "";
            txtEmail.Text = "";
            txtSenha.Text = "";
            txtUsuario.Text = "";
            mskCPF.Text = "";
            mskDataNascimento.Text = "";
            mskRG.Text = "";
            mskTelefone.Text = "";
            ID = 0;
        }

        private void frmConsultarFuncionarios_Load(object sender, EventArgs e)
        {
            dtFuncionarios.Columns[0].HeaderText = "Código";
            dtFuncionarios.Columns[1].HeaderText = "Nome";
            dtFuncionarios.Columns[2].HeaderText = "RG";
            dtFuncionarios.Columns[3].HeaderText = "Data de Nascimento";
            dtFuncionarios.Columns[4].HeaderText = "CPF";
            dtFuncionarios.Columns[5].HeaderText = "Email";
            dtFuncionarios.Columns[6].HeaderText = "Telefone";
            dtFuncionarios.Columns[7].HeaderText = "Usuário";
            dtFuncionarios.Columns[8].HeaderText = "Senha";
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtEmail.Text != "" && txtNome.Text != "" && txtSenha.Text != "" && txtUsuario.Text != "" && mskCPF.Text != "" && mskDataNascimento.Text != "" && mskRG.Text != "" && mskTelefone.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("INSERT INTO Funcionarios (nomecompleto, rg, data_nascimento, cpf, email, telefone, usuario, senha) VALUES (@nomecompleto, @rg, @data_nascimento, @cpf, @email, @telefone, @usuario, @senha)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@nomecompleto", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@data_nascimento", Convert.ToDateTime(mskDataNascimento.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@email", Convert.ToString(txtEmail.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@usuario", Convert.ToString(txtUsuario.Text.ToString()));
                    cmd.Parameters.AddWithValue("@senha", Convert.ToString(txtSenha.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro incluído com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {

            if (txtCodigo.Text != "" && txtEmail.Text != "" && txtNome.Text != "" && txtSenha.Text != "" && txtUsuario.Text != "" && mskCPF.Text != "" && mskDataNascimento.Text != "" && mskRG.Text != "" && mskTelefone.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("UPDATE Funcionarios SET nomecompleto=@nomecompleto, rg=@rg, data_nascimento=@data_nascimento, cpf=@cpf, email=@email, telefone=@telefone, usuario=@usuario, senha=@senha WHERE codfuncionario=@codfuncionario", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@codfuncionario", Convert.ToInt32(ID));
                    cmd.Parameters.AddWithValue("@nomecompleto", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@data_nascimento", Convert.ToDateTime(mskDataNascimento.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@email", Convert.ToString(txtEmail.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@usuario", Convert.ToString(txtUsuario.Text.ToString()));
                    cmd.Parameters.AddWithValue("@senha", Convert.ToString(txtSenha.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro atualizado com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
             }
             else
             {
                MessageBox.Show("Informe todos os dados requeridos");
             }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                if (MessageBox.Show("Deseja Deletar este registro ?", "Infomarket", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        cmd = new SqlCommand("DELETE Funcionarios WHERE codfuncionario=@codfuncionario", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@codfuncionario", ID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("registro deletado com sucesso...!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro : " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                        ExibirDados();
                        LimparDados();
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecione um registro para deletar");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtCodigo.Text = "";
            txtEmail.Text = "";
            txtSenha.Text = "";
            txtUsuario.Text = "";
            mskCPF.Text = "";
            mskDataNascimento.Text = "";
            mskRG.Text = "";
            mskTelefone.Text = "";
            ID = 0;
        }

        private void dtFuncionarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = Convert.ToInt32(dtFuncionarios.Rows[e.RowIndex].Cells[0].Value.ToString());
            txtCodigo.Text = dtFuncionarios.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = dtFuncionarios.Rows[e.RowIndex].Cells[1].Value.ToString();
            mskRG.Text = dtFuncionarios.Rows[e.RowIndex].Cells[2].Value.ToString();
            mskDataNascimento.Text = dtFuncionarios.Rows[e.RowIndex].Cells[3].Value.ToString();
            mskCPF.Text = dtFuncionarios.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtEmail.Text = dtFuncionarios.Rows[e.RowIndex].Cells[5].Value.ToString();
            mskTelefone.Text = dtFuncionarios.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtUsuario.Text = dtFuncionarios.Rows[e.RowIndex].Cells[7].Value.ToString();
            txtSenha.Text = dtFuncionarios.Rows[e.RowIndex].Cells[8].Value.ToString();
        }
    }
}


