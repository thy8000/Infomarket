﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmCadastro : Form
    {
        SqlConnection con = Conexao.getConnection();
        SqlCommand cmd;

        public frmCadastro()
        {
            InitializeComponent();
        }

        public void Limpar()
        {
            txtEmail.Clear();
            txtNomeCompleto.Clear();
            txtSenha.Clear();
            txtUsuario.Clear();
            mskCPF.Clear();
            mskNascimento.Clear();
            mskRG.Clear();
            mskTelefone.Clear();
        }

        private void Cadastro_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtEmail.Clear();
            txtNomeCompleto.Clear();
            txtSenha.Clear();
            txtUsuario.Clear();
            mskCPF.Clear();
            mskNascimento.Clear();
            mskRG.Clear();
            mskTelefone.Clear();

            txtNomeCompleto.Focus();  
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            if (txtNomeCompleto.Text != "" && txtEmail.Text != "" && txtSenha.Text != "" && txtUsuario.Text != "" && mskCPF.Text != "" && mskNascimento.Text != "" && mskRG.Text != "" && mskTelefone.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("INSERT INTO Funcionarios(nomecompleto, rg, data_nascimento, cpf, email, telefone, usuario, senha) VALUES(@nomecompleto, @rg, @data_nascimento, @cpf, @email, @telefone, @usuario, @senha)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@nomecompleto", Convert.ToString(txtNomeCompleto.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@data_nascimento", Convert.ToDateTime(mskNascimento.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@email", Convert.ToString(txtEmail.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@usuario", Convert.ToString(txtUsuario.Text.ToString()));
                    cmd.Parameters.AddWithValue("@senha", Convert.ToString(txtSenha.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro incluído com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    Limpar();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }
    }
}
