﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmLogin : Form
    {
        private bool Logado = false;

        bool VerificaLogin()
        {
            bool result = false;
            SqlConnection con = Conexao.getConnection();
            SqlCommand cmd;

            try
                {
                    cmd = new SqlCommand("SELECT * from Funcionarios where usuario = '" +txtUsuario.Text + "' and senha = '" +txtSenha.Text + "';", con);
                    con.Open();
                    SqlDataReader dados = cmd.ExecuteReader();
                    result = dados.HasRows;

                }
                catch (SqlException e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    con.Close();
                }
            
            return result;
        }

        public frmLogin()
        {
            InitializeComponent();
        }

        

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            // Criando uma variável do tipo form e atribuindo para o frmCadastro.
            Form frmCadastro = new frmCadastro();

            // Deixando o frmLogin invisível, e abrindo o frmCadastro com o método ShowDialog
            this.Visible = false;
            frmCadastro.ShowDialog();

            // O frmLogin vai permanecer invisível até o frmCadastro ser fechado, e quando isto acontecer ele abrirá denovo.
            this.Visible = true;
            
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {

            bool result = VerificaLogin();

            Logado = result;

            if (result)
            {
                Form frmMenu = new frmMenu();

                MessageBox.Show("Seja bem vindo!");
                this.Visible = false;
                frmMenu.Show();
                
            }
            else
            {
                MessageBox.Show("Usuário ou senha incorreto!");
            }
        }

        private void frmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Logado)
            {
                Application.Exit();
            }

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
