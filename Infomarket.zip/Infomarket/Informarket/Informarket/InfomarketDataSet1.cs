﻿namespace Informarket
{


    partial class InfomarketDataSet
    {
    }
}

namespace Informarket.InfomarketDataSetTableAdapters {
    
    
    public partial class PedidosTableAdapter {
    }
}
