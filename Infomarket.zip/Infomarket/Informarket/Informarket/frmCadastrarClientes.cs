﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Informarket
{
    public partial class frmCadastrarClientes : Form
    {
        SqlConnection con = Conexao.getConnection();
        SqlCommand cmd;
        SqlDataAdapter adapt;
        SqlDataReader reader;
        int ID = 0;

        public frmCadastrarClientes()
        {
            InitializeComponent();
            ExibirDados();
        }

        public class Funcionarios
        {
            public int codfuncionario { get; set; }
        }

        public IEnumerable<Funcionarios> GetFuncionarios()
        {
            cmd = new SqlCommand("SELECT codfuncionario FROM Funcionarios ORDER BY codfuncionario", con);
            {
                con.Open();
                reader = cmd.ExecuteReader();
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            yield return new Funcionarios()
                            {
                                codfuncionario = reader.GetInt32(0),
                            };
                        }
                    }
                }
                con.Close();
            }
        }

        private void ExibirDados()
        {
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                adapt = new SqlDataAdapter("SELECT c.codcli, c.nome, c.rg, c.cpf, c.cidade, c.telefone, c.celular, f.nomecompleto FROM Clientes c INNER JOIN Funcionarios f ON (c.codfuncionario = f.codfuncionario)", con);
                adapt.Fill(dt);
                dtClientes.DataSource = dt;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
        }

        private void LimparDados()
        {
            txtNome.Text = "";
            mskCelular.Text = "";
            mskCPF.Text = "";
            mskRG.Text = "";
            mskTelefone.Text = "";
            txtCodigo.Text = "";
            txtCidade.Text = "";
            ID = 0;
        }

        private void frmCadastrarClientes_Load(object sender, EventArgs e)
        {
            dtClientes.Columns[0].HeaderText = "Código";
            dtClientes.Columns[1].HeaderText = "Nome";
            dtClientes.Columns[2].HeaderText = "RG";
            dtClientes.Columns[3].HeaderText = "CPF";
            dtClientes.Columns[4].HeaderText = "Cidade";
            dtClientes.Columns[5].HeaderText = "Telefone";
            dtClientes.Columns[6].HeaderText = "Celular";
            dtClientes.Columns[7].HeaderText = "Nome Funcionário";

            cbFuncionario.DropDownStyle = ComboBoxStyle.DropDownList;
            cbFuncionario.DataSource = GetFuncionarios().ToArray();
            cbFuncionario.ValueMember = "codfuncionario";
            cbFuncionario.DisplayMember = "codfuncionario";
            cbFuncionario.Update();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {

        }

        private void dtClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
        }

        private void btnCadastrar_Click_1(object sender, EventArgs e)
        {
            if (txtNome.Text != "" && mskRG.Text != "" && mskCPF.Text != "" && txtCidade.Text != "" && mskTelefone.Text != "" && mskCelular.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("INSERT INTO Clientes (nome, rg, cpf, cidade, telefone, celular, codfuncionario) VALUES (@nome, @rg, @cpf, @cidade, @telefone, @celular, @codfuncionario)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@nome", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cidade", Convert.ToString(txtCidade.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@celular", Convert.ToInt64(mskCelular.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codfuncionario", Convert.ToInt64(cbFuncionario.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro incluído com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void btnAtualizar_Click_1(object sender, EventArgs e)
        {
            if (txtNome.Text != "" && mskRG.Text != "" && mskCPF.Text != "" && txtCidade.Text != "" && mskTelefone.Text != "" && mskCelular.Text != "")
            {
                try
                {
                    cmd = new SqlCommand("UPDATE Clientes SET nome=@nome, rg=@rg, cpf=@cpf, cidade=@cidade, telefone=@telefone, celular=@celular, codfuncionario=@codfuncionario WHERE codcli=@codcli", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@codcli", Convert.ToInt32(ID));
                    cmd.Parameters.AddWithValue("@nome", Convert.ToString(txtNome.Text.ToString()));
                    cmd.Parameters.AddWithValue("@rg", Convert.ToInt64(mskRG.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cpf", Convert.ToInt64(mskCPF.Text.ToString()));
                    cmd.Parameters.AddWithValue("@cidade", Convert.ToString(txtCidade.Text.ToString()));
                    cmd.Parameters.AddWithValue("@telefone", Convert.ToInt64(mskTelefone.Text.ToString()));
                    cmd.Parameters.AddWithValue("@celular", Convert.ToInt64(mskCelular.Text.ToString()));
                    cmd.Parameters.AddWithValue("@codfuncionario", Convert.ToInt64(cbFuncionario.Text.ToString()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registro atualizado com sucesso...");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro : " + ex.Message);
                }
                finally
                {
                    con.Close();
                    ExibirDados();
                    LimparDados();
                }
            }
            else
            {
                MessageBox.Show("Informe todos os dados requeridos");
            }
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                if (MessageBox.Show("Deseja Deletar este registro ?", "Infomarket", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        cmd = new SqlCommand("DELETE Clientes WHERE codcli=@codcli", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@codcli", ID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("registro deletado com sucesso...!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro : " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                        ExibirDados();
                        LimparDados();
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecione um registro para deletar");
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            txtNome.Text = "";
            mskRG.Text = "";
            mskCPF.Text = "";
            txtCidade.Text = "";
            mskTelefone.Text = "";
            mskCelular.Text = "";
            txtCodigo.Text = "";
            txtNome.Focus();
        }

        private void dtClientes_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            ID = Convert.ToInt32(dtClientes.Rows[e.RowIndex].Cells[0].Value.ToString());
            txtCodigo.Text = dtClientes.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtNome.Text = dtClientes.Rows[e.RowIndex].Cells[1].Value.ToString();
            mskRG.Text = dtClientes.Rows[e.RowIndex].Cells[2].Value.ToString();
            mskCPF.Text = dtClientes.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtCidade.Text = dtClientes.Rows[e.RowIndex].Cells[4].Value.ToString();
            mskTelefone.Text = dtClientes.Rows[e.RowIndex].Cells[5].Value.ToString();
            mskCelular.Text = dtClientes.Rows[e.RowIndex].Cells[6].Value.ToString();
        }

        private void lblCPF_Click(object sender, EventArgs e)
        {

        }
    }
}

