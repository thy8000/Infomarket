﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Informarket
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {

        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrarProdutos_Click(object sender, EventArgs e)
        {
            Form frmCadastrarProdutos = new frmCadastrarProdutos();

            frmCadastrarProdutos.Show();
        }

        private void btnCadastrarClientes_Click(object sender, EventArgs e)
        {
            Form frmCadastrarClientes = new frmCadastrarClientes();

            frmCadastrarClientes.Show();
        }

        private void cadastrarClientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmCadastrarClientes = new frmCadastrarClientes();

            frmCadastrarClientes.Show();
        }

        private void cadastrarProdutosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmCadastrarProdutos = new frmCadastrarProdutos();

            frmCadastrarProdutos.Show();
        }

        private void btnConsultarProdutos_Click(object sender, EventArgs e)
        {
            Form frmConsultarProdutos = new frmPesquisarPedidos();

            frmConsultarProdutos.Show();
        }

        private void consultarProdutosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form frmConsultarProdutos = new frmPesquisarPedidos();

            frmConsultarProdutos.Show();
        }

        private void btnConsultarClientes_Click(object sender, EventArgs e)
        {
            Form frmConsultarClientes = new frmCadastrarPedidos();

            frmConsultarClientes.Show();
        }

        private void consultarProdutosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmConsultarClientes = new frmCadastrarPedidos();

            frmConsultarClientes.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form frmLogin = new frmLogin();
            this.Close();
            frmLogin.Visible = true;
        }

        private void sairDoSistemaLogoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmLogin = new frmLogin();
            this.Close();
            frmLogin.Visible = true;
        }

        private void btnCategorias_Click(object sender, EventArgs e)
        {
            Form frmCadastrarCategorias = new frmCadastrarFabricante();

            frmCadastrarCategorias.Show();
        }

        private void cadastrarCategoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmCadastrarCategorias = new frmCadastrarFabricante();

            frmCadastrarCategorias.Show();
        }

        private void cadastrarPedidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmCadastrarPedidos = new frmCadastrarPedidos();

            frmCadastrarPedidos.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form frmConsultarPedidos = new frmPesquisarPedidos();

            frmConsultarPedidos.Show();
        }

        private void consultarPedidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmConsultarPedidos = new frmPesquisarPedidos();

            frmConsultarPedidos.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form frmConsultarFuncionarios = new frmConsultarFuncionarios();

            frmConsultarFuncionarios.Show();
        }

        private void consultarFuncionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmConsultarFuncionarios = new frmConsultarFuncionarios();

            frmConsultarFuncionarios.Show();
        }
    }
}
